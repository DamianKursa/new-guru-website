import React from "react"

const Button= () => (
    <button>
        
    </button>
  )
  
  export default Button