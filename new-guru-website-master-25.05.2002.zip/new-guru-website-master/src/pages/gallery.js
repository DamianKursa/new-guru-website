import React from "react"

const GalleryPage = () => (
    <div>
      <h1>gallery Page</h1>
      <p>Welcome to page 2</p>
    </div>
  )
  
  export default GalleryPage
  