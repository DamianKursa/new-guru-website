import React from "react"

const ContactPage = () => (
    <div>
      <h1>contact Page</h1>
      <p>Welcome to page 2</p>
    </div>
  )
  
  export default ContactPage
  