import React from "react"

const AboutPage = () => (
    <div>
      <h1>about Page</h1>
      <p>Welcome to page 2</p>
    </div>
  )
  
  export default AboutPage
  